import secrets
value=secrets.token_hex(16)
print(value)